# Saved blog coverage replay

Node.js 24 or later. All 109 JavaScript files and 105 source-map bindings match the SHA-256 values in the original report. Coverage files are the original three recordings. No new browser visit is needed.

```sh
npx @yceffort/coldpath@0.3.1 analyze --dir files \
  --coverage coverage/initial.coverage.json \
  --coverage coverage/search.coverage.json \
  --coverage coverage/zoom-diagram.coverage.json \
  --initial-scenario initial --scenario-order initial,search,zoom-diagram \
  --json report.json
```

Compare totals and the SiteSearch mapping diagnostics with expected.json. The import graph is omitted, so import-path recommendations and graph warnings are outside this replay. Unmeasured files are matched against manifest.json; measured JS and maps are also hash-checked by coldpath against the original coverage envelopes.
