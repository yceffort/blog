(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,563122,e=>{"use strict";var i=e.i(416462);e.i(997564),e.s([],896234),e.i(896234),e.s(["createGitGraphServices",()=>i.createGitGraphServices],563122)}]);

//# sourceMappingURL=37tx0r2vmo_ix.js.map