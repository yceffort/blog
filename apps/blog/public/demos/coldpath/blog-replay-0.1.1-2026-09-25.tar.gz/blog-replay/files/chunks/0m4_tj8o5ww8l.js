(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,613245,t=>{"use strict";var e=t.i(123237);t.s(["default",0,function({lang:t}){return(0,e.useEffect)(()=>{document.documentElement.lang=t},[t]),null}])}]);

//# sourceMappingURL=3h21yyi-xt32x.js.map