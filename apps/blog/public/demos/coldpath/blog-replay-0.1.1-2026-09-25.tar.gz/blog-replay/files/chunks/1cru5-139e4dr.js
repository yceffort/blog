(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,53056,e=>{"use strict";var r=e.i(342293);e.i(997564),e.s([],748436),e.i(748436),e.s(["createWardleyServices",()=>r.createWardleyServices],53056)}]);

//# sourceMappingURL=0tx824hrjj6rj.js.map