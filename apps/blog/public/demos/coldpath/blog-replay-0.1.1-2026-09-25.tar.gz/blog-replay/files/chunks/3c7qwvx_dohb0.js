(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,620405,e=>{"use strict";var t=e.i(905843),l=e.i(517279);e.s(["channel",0,(e,o)=>t.default.lang.round(l.default.parse(e)[o])],620405)},85876,e=>{"use strict";var t=(0,e.i(730522).__name)(()=>`
  /* Font Awesome icon styling - consolidated */
  .label-icon {
    display: inline-block;
    height: 1em;
    overflow: visible;
    vertical-align: -0.125em;
  }
  
  .node .label-icon path {
    fill: currentColor;
    stroke: revert;
    stroke-width: revert;
  }
`,"getIconStyles");e.s(["getIconStyles",0,t])}]);

//# sourceMappingURL=44w9sn38ebpb5.js.map