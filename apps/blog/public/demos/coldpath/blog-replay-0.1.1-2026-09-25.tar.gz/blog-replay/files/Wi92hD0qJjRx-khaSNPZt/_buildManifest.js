self.__BUILD_MANIFEST = {
  "__rewrites": {
    "afterFiles": [
      {
        "source": "/llms.txt",
        "destination": "/api/llms"
      },
      {
        "source": "/llms-full.txt",
        "destination": "/api/llms-full"
      },
      {
        "source": "/en/llms-full.txt",
        "destination": "/api/llms-full/en"
      },
      {
        "source": "/en/:year(\\d{4})/:slug*.md",
        "destination": "/api/posts-raw/en/:year/:slug*"
      },
      {
        "source": "/:year(\\d{4})/:slug*.md",
        "destination": "/api/posts-raw/:year/:slug*"
      }
    ],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/_app",
    "/_error"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()