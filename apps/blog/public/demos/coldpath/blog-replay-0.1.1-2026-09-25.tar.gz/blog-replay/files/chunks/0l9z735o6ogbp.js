(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,602873,e=>{"use strict";var i=e.i(972157);e.i(997564),e.s([],612896),e.i(612896),e.s(["createEventModelingServices",()=>i.createEventModelingServices],602873)}]);

//# sourceMappingURL=048oaml8_20i5.js.map