Chart worker source snapshot, 2026-11-14

These are exact source files from apps/blog/src/components/post/charts.
They include the canvas renderer and worker, not the whole Markdown integration.
Requires React, Chart.js 4.6.1 and the existing StyleX setup in the blog.
Give ChartCanvas a parent with an explicit height; RenderInput is defined in
chartEngine.ts and ChartView in types.ts. Only plain data crosses the worker
boundary. No environment variables or credentials are included.

This snapshot was added after the November 12 memory measurements. It was not
part of that experiment. manifest.json records SHA-256 hashes of each source.
